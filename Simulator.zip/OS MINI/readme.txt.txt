1) Go to home
2) Open index.html